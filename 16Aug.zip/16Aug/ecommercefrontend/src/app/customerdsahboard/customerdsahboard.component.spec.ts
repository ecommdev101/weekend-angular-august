import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerdsahboardComponent } from './customerdsahboard.component';

describe('CustomerdsahboardComponent', () => {
  let component: CustomerdsahboardComponent;
  let fixture: ComponentFixture<CustomerdsahboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerdsahboardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerdsahboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
