import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserValidator } from '../User.Validator';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private userService: UserService, private router: Router) { }

  XYZ = 100;

  loginForm: FormGroup = new FormGroup(
    {
      username: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]),
      password: new FormControl('', [Validators.required, Validators.minLength(5),
      Validators.maxLength(50),
      UserValidator.checkForNoSpace

      ])
    }
  )

  loginUser() {



    console.log(this.loginForm.value);

    const user = {
      email: this.loginForm.value.username,
      password: this.loginForm.value.password,
    }

    this.userService.userLogin(user).subscribe(
      {
        next: (response: any) => {
          console.log("Login successful", response);

          if (response.body.token) {

             sessionStorage.setItem("token", response.body.token);
             sessionStorage.setItem("role", response.body.role);

            if (response.body.role == "ROLE_ADMIN") {
              this.router.navigateByUrl('/admindashboard');
              return;
            }
             if (response.body.role == "ROLE_CUSTOMER") {
              this.router.navigateByUrl('/customerdashboard');
            }
          }
          else {
            alert("Login failed, please try again");
          }


        },
        error: (error) => {
          console.error("Login failed", error);
        },
        complete: () => {
          console.log("Login request completed");
        }
      }
    )
  }

}
