import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CustomerdsahboardComponent } from './customerdsahboard/customerdsahboard.component';
import { AdmindsahboardComponent } from './admindsahboard/admindsahboard.component';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';

export const routes: Routes = [

    {
        path:"login",
        component:LoginComponent
    },
    {
        path:'register',
        component:RegisterComponent
    },
    {
        path:'customerdashboard',
        component:CustomerdsahboardComponent
    },
    {
        path:'admindashboard',
        component:AdmindsahboardComponent
    },
    {
        path:'accessdenied',
        component: AccessdeniedComponent
    }
];
