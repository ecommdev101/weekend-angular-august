import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink,CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  constructor(private router: Router) { }

  isLoggedIn(): boolean {
    return sessionStorage.getItem("token") !== null;
  }

  getRole(): string | null {
    return sessionStorage.getItem("role");
  }

  logout() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("role");
     this.router.navigateByUrl('/login');
  }

}
