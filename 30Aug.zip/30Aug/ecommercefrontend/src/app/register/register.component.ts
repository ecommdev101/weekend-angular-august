import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [FormsModule,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

   email:string = '';
   password:string = '';
   name:string = "";


   constructor(private userService:UserService, private router:Router) { 

   }

   registerUser(form:any){
     console.log(form.value);

      const user = {
        email: form.value.email,
        passwordHash: form.value.password,
        name: form.value.name,
        role: 'CUSTOMER'
      };

      this.userService.userRegister(user).subscribe({

        next: (result) => {
          console.log(result);
                if(result){
                  alert("Registration successful");
                   this.router.navigateByUrl('/login');
                }
        },
        error: (error) => {
          console.error(error);
          alert("Something went wrong during registration");
        }

      })
   }

}
