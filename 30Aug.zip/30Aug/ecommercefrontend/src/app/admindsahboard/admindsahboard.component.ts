import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-admindsahboard',
  imports: [],
  templateUrl: './admindsahboard.component.html',
  styleUrl: './admindsahboard.component.css'
})
export class AdmindsahboardComponent {

   constructor(private router:Router) { 
    var token = sessionStorage.getItem("token");
    var role = sessionStorage.getItem("role");
    if (!token || !role) {
          this.router.navigateByUrl('/login');
   }
    if(role != "ROLE_ADMIN") {
      this.router.navigateByUrl('/accessdenied');
}
   }

}
