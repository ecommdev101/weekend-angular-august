import { Component } from '@angular/core';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CashondeliveryComponent } from '../cashondelivery/cashondelivery.component';



@Component({
  selector: 'app-cart',
  imports: [CommonModule,CashondeliveryComponent],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {

  paymentType: string = '';

  constructor(private productService: ProductService, private router: Router) {}

  cartItems: any[] = [];

  ngOnInit() {
    this.getCartItems();
  }

  getCartItems() {
    let userId = sessionStorage.getItem("userId");

    this.productService.getCartItems(userId).subscribe({
      next: (response: any) => {
        this.cartItems = response.items;
        this.cartItems = this.convertProductIdsToProducts();
      },
      error: (error) => {
        console.error('Error fetching cart items:', error);
      }
    });
  }

  convertProductIdsToProducts() {
    let products = sessionStorage.getItem("products");

    if (products) {
      let productsArray = JSON.parse(products);

      return this.cartItems.map((item) => {
        let product = productsArray.find((p: any) => p.productId === item.productId);
        return { ...item, product };
      });
    }
    return [];
  }

  removeFromCart(productId: number) {
    let userId = sessionStorage.getItem("userId");
    this.productService.removeCartItem(productId, userId).subscribe({
      next: () => {
        this.cartItems = this.cartItems.filter(item => item.productId !== productId);
        alert("Product removed from cart successfully");
      },
      error: (err) => {
        console.error("Error removing item:", err);
      }
    });
  }

  updateQuantity(item: any, newQuantity: number) {
    if (newQuantity < 1) return;

    let userId = sessionStorage.getItem("userId");

    this.productService.updateCartItemQuantity(item.productId, userId, newQuantity).subscribe({
      next: () => {
        this.cartItems = this.cartItems.map(cartItem =>
          cartItem.productId === item.productId
            ? { ...cartItem, quantity: newQuantity }
            : cartItem
        );
      },
      error: (err) => {
        console.error("Error updating quantity:", err);
      }
    });
  }

  getCartTotal(): number {
    return this.cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  }

  // Payment methods
  payWithCOD() {
    console.log("Cash on Delivery selected.");
    this.paymentType = 'COD';
  
  }

  payWithRazorpay() {
   alert("Online Payment via Razorpay selected.");

    
  }
}
