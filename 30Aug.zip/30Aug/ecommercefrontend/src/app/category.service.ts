import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient) { }

  getAllCategories() {
    return this.http.get("http://localhost:9102/categories");
  }

  addCategory(category: any) {
    const token = sessionStorage.getItem('token');   // <-- fetch the token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    return this.http.post("http://localhost:9102/categories", category, { headers });
  }

}
