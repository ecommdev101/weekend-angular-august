import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CustomerdsahboardComponent } from './customerdsahboard/customerdsahboard.component';
import { AdmindsahboardComponent } from './admindsahboard/admindsahboard.component';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { CashondeliveryComponent } from './cashondelivery/cashondelivery.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { CategorymanagementComponent } from './categorymanagement/categorymanagement.component';

export const routes: Routes = [
    {
        path:"",
        component:HomeComponent
    },
    {
        path:"login",
        component:LoginComponent
    },
    {
        path:'register',
        component:RegisterComponent
    },
    {
        path:'customerdashboard',
        component:CustomerdsahboardComponent
    },
    {
        path:'admindashboard',
        component:AdmindsahboardComponent
    },
    {
        path:'accessdenied',
        component: AccessdeniedComponent
    },
    {
        path:"cart", 
        component:CartComponent
    },
    {
        path:'cashondelivery',
        component:CashondeliveryComponent,
        
    },
     {
        path:'productmanage',
        component:ProductManagementComponent,
    },
    {
        path:'categorymanage',
        component:CategorymanagementComponent
    }
];
