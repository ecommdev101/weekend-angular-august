import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-product',
  imports: [CommonModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent implements OnInit {

    private cartItemCount = new BehaviorSubject<number>(0);
  cartItemCount$ = this.cartItemCount.asObservable();

  constructor(private productService: ProductService) { }

  products: any[] = [];

  ngOnInit() {
    console.log('Fetching products...');
    this.productService.getProducts().subscribe(
      {
        next: (response:any) => {
            console.log('Products fetched successfully:', response);
          this.products = response.content;
          sessionStorage.setItem("products", JSON.stringify(this.products));
        },
        error: (error) => {
          console.error('Error fetching products:', error);
        }
      }
    );
  }

  addToCart(product: any) {

     console.log("Adding to cart:", product);

      const cartData = {
        productId: product.productId,
        quantity: 1,
      }

      let userId = sessionStorage.getItem("userId");

      this.productService.addToCartImpl(cartData,userId).subscribe(
        {

          next: (response:any) => {
              console.log('Product added to cart successfully:', response);
            this.cartItemCount.next(response.items.length);

              alert("Product added to cart successfully");
          },
          error: (error) => {
            console.error('Error adding product to cart:', error);
            alert("Error adding product to cart");
          }

        }
      )

    }

  

  }



