import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-navbar',
  imports: [RouterLink,CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent  {

  cartItemCount = 0;

  constructor(private router: Router, private productService:ProductService) { }

  isLoggedIn(): boolean {
    return sessionStorage.getItem("token") !== null;
  }

  getRole(): string | null {
    return sessionStorage.getItem("role");
  }

  logout() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("role");
     this.router.navigateByUrl('/login');
  }

  ngOnInit() {
      if(sessionStorage.getItem("role") == "ROLE_CUSTOMER")
      {
      this.getCartItemsCount();
      }
  }

  getCartItemsCount() {
    let userId = sessionStorage.getItem("userId");
    if(userId) {
      this.productService.getCartItems(userId).subscribe(
        {
          next: (response:any) => {
              console.log('Cart items fetched successfully:', response);
            this.cartItemCount = response.items.length;
          },
          error: (error) => {
            console.error('Error fetching cart items:', error);
          }
        }
      );
    }
  }

}
