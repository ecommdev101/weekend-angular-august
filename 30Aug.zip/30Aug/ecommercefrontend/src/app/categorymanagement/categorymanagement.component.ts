import { Component } from '@angular/core';
import { CategoryService } from '../category.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-categorymanagement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './categorymanagement.component.html',
  styleUrl: './categorymanagement.component.css'
})
export class CategorymanagementComponent {

  categories: any[] = [];          // displayed categories
  allCategories: any[] = [];       // original list (for filtering)
  sortDirection: 'asc' | 'desc' = 'asc';
  searchTerm: string = '';         // for search input

  newCategory = {
    name: '',
    description: ''
  };

  constructor(private categoryService: CategoryService) {}

  getAllCategories() {
    this.categoryService.getAllCategories().subscribe({
      next: (data) => {
        this.categories = data as any[];
        this.allCategories = data as any[];   // keep a copy
      },
      error: (error) => {
        console.error(error);
      }
    });
  }

  ngOnInit(): void {
    this.getAllCategories();
  }

  addCategory() {
    if (!this.newCategory.name.trim() || !this.newCategory.description.trim()) {
      alert('Please fill in both name and description.');
      return;
    }

    this.categoryService.addCategory(this.newCategory).subscribe({
      next: () => {
        alert('Category added successfully!');
        this.newCategory = { name: '', description: '' };
        this.getAllCategories();
      },
      error: (error) => {
        console.error(error);
        alert('Failed to add category. Please try again.');
      }
    });
  }

  sortByName() {
    this.categories = [...this.categories].sort((a, b) => {
      const nameA = a.name?.toLowerCase() ?? '';
      const nameB = b.name?.toLowerCase() ?? '';
      if (nameA < nameB) return this.sortDirection === 'asc' ? -1 : 1;
      if (nameA > nameB) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  }

  filterCategories() {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) {
      this.categories = [...this.allCategories];
    } else {
      this.categories = this.allCategories.filter(cat =>
        cat.name?.toLowerCase().includes(term) ||
        cat.description?.toLowerCase().includes(term)
      );
    }
  }
}
