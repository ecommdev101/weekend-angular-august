import { Component } from '@angular/core';

@Component({
  selector: 'app-accessdenied',
  imports: [],
  templateUrl: './accessdenied.component.html',
  styleUrl: './accessdenied.component.css'
})
export class AccessdeniedComponent {

  constructor() { }

  message: string = "Access Denied. You do not have permission to view this page.";

}
