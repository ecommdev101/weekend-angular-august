import { Component } from '@angular/core';

@Component({
  selector: 'app-cashondelivery',
  imports: [],
  templateUrl: './cashondelivery.component.html',
  styleUrl: './cashondelivery.component.css'
})
export class CashondeliveryComponent {
totalAmount: number = 0;

  constructor() {
    // ideally, fetch this from order/cart service
    let amount = sessionStorage.getItem("cartTotal");
    this.totalAmount = amount ? parseFloat(amount) : 200;
  }
}
