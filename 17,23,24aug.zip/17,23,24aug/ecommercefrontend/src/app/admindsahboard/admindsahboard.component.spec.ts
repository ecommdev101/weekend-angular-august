import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmindsahboardComponent } from './admindsahboard.component';

describe('AdmindsahboardComponent', () => {
  let component: AdmindsahboardComponent;
  let fixture: ComponentFixture<AdmindsahboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdmindsahboardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdmindsahboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
