import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserValidator } from '../User.Validator';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginForm:FormGroup =new FormGroup(
    {
      username: new FormControl('',[Validators.required, Validators.minLength(6), Validators.maxLength(50)]),
      password: new FormControl('',[Validators.required, Validators.minLength(8),
         Validators.maxLength(50),
         UserValidator.checkForNoSpace,
         UserValidator.checkForUpperCase,
         UserValidator.checkForLowerCase,
          UserValidator.checkForNumber,
          UserValidator.checkForSpecialCharacter

])
    }
  )

  loginUser(){
      console.log(this.loginForm.value);
  }

}
