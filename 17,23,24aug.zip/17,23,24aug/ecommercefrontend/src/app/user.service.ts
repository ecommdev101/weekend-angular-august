import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

   userLogin(user:any){
         return this.httpClient.post("http://localhost:9100/common/login",user,{
           observe:'response'})
   }

   userRegister(user:any){
    return this.httpClient.post("http://localhost:9100/common/register",user);
   }

}
