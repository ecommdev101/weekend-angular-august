import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductComponent } from '../product/product.component';

@Component({
  selector: 'app-customerdsahboard',
  imports: [ProductComponent],
  templateUrl: './customerdsahboard.component.html',
  styleUrl: './customerdsahboard.component.css'
})
export class CustomerdsahboardComponent {

   constructor(private router:Router) { 
    var token = sessionStorage.getItem("token");
    var role = sessionStorage.getItem("role");
    if (!token || !role) {
          this.router.navigateByUrl('/login');
   }
    if(role != "ROLE_CUSTOMER") {
      this.router.navigateByUrl('/accessdenied');
}
   }
}
