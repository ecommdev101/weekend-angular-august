import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {



  constructor(private httpClient:HttpClient) { }

   getProducts() {
    return this.httpClient.get("http://localhost:9102/products");
   }

   addToCartImpl(cartData:any, productId:any) {
    return this.httpClient.post(`http://localhost:9103/cart/${productId}/items`, cartData);
   }

    getCartItems(userId:any) {
      return this.httpClient.get(`http://localhost:9103/cart/${userId}`);
    }

     removeCartItem(productId:any, userId:any) {
      return this.httpClient.delete(`http://localhost:9103/cart/${userId}/items/${productId}`);
     }

     updateCartItemQuantity(productId:any, userId:any, quantity:any) {
      const body = { quantity: quantity };
      return this.httpClient.put(`http://localhost:9103/cart/${userId}/items/${productId}`, body);
     }
   
}
