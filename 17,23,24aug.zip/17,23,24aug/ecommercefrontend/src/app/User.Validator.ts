import { AbstractControl, ValidationErrors } from "@angular/forms";

export class UserValidator {

    static checkForNoSpace(control:AbstractControl): ValidationErrors | null
    {

               const value = control.value; 
               if(value.includes(' ')){
                return {checkForNoSpace:true}
               }
             return null;
    }

    static checkForUpperCase(control:AbstractControl): ValidationErrors | null{

         const value = control.value; 

           var result = /[A-Z]/.test(value)
          if(result){
                return null
               }
               else{
                     return {checkForUpperCase:true};
               }
             
    }

    static checkForLowerCase(control:AbstractControl): ValidationErrors | null{

         const value = control.value; 

           var result = /[a-z]/.test(value)
          if(result){
                return null
               }
               else{
                     return {checkForLowerCase:true};
               }
             
    }

    static checkForNumber(control:AbstractControl): ValidationErrors | null{

         const value = control.value; 

           var result = /[0-9]/.test(value)
          if(result){
                return null
               }
               else{
                     return {checkForNumber:true};
               }
             
    }

    static checkForSpecialCharacter(control:AbstractControl): ValidationErrors | null{

         const value = control.value; 

           var result = /[!@#$%^&*(),.?":{}|<>]/.test(value)
          if(result){
                return null
               }
               else{
                     return {checkForSpecialCharacter:true};
               }
             
    }

}
